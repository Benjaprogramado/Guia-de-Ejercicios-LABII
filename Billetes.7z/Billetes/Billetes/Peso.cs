﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Peso
    {
        private double cantidad;
        private static double cotizarRespectoDolar;

        public Peso()
        {
            Peso.cotizarRespectoDolar = (1/38.33);
        }
        public Peso(double cantidad) : this()
        {
            this.cantidad = cantidad;
        }
        public Peso(double cantidad, double cotizacion) : this(cantidad)
        {
            cotizarRespectoDolar = cotizacion;
        }



        public static double GetCotizacion()
        {
            return Peso.cotizarRespectoDolar;
        }
        public double GetCantidad()
        {
            return this.cantidad; 
        }


        public static explicit operator Dolar(Peso p)
        {
            double cantidad = p.GetCantidad() / Peso.cotizarRespectoDolar;
            Dolar dolar = new Dolar(cantidad);
            return dolar;
        }
        public static explicit operator Euro(Peso p)
        {
            Euro euro = new Euro();    
            Euro euroADolares = (Dolar)euro;
            Dolar pesoADolares = (Dolar)p;
        

            return euro;
        }



    }


}
