﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Billetes
{
    public class Dolar
    {
        private double cantidad;
        private static double cotizarRespectoDolar;

        public Dolar()
        {
            Dolar.cotizarRespectoDolar = 1;
        }
        public Dolar(double cantidad) : this()
        {
            this.cantidad = cantidad;
        }
        public Dolar(double cantidad, double cotizacion) : this(cantidad)
        {
            cotizarRespectoDolar = cotizacion;
        }




        public static double GetCotizacion()
        {
            return Dolar.cotizarRespectoDolar;
        }
        public double GetCantidad()
        {
            return this.cantidad;
        }








    }
}
