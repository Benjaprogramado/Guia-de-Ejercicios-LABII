﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Euro
    {
        private double cantidad;
        private static double cotizarRespectoDolar;

        public Euro()
        {
            Euro.cotizarRespectoDolar = 1.16;
        }
        public Euro(double cantidad) : this()
        {
            this.cantidad = cantidad;
        }
        public Euro(double cantidad, double cotizacion) : this(cantidad)
        {
            cotizarRespectoDolar = cotizacion;
        }




        public static double GetCotizacion()
        {
            return Euro.cotizarRespectoDolar;
        }
        public double GetCantidad()
        {
            return this.cantidad;
        }


        public static explicit operator Dolar(Euro e)
        {
            double cantidad = e.GetCantidad() * Euro.cotizarRespectoDolar;
            Dolar dolar = new Dolar(cantidad);
            return dolar;
        }



    }
}
