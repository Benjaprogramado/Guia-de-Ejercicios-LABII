﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PalabrasForm
{
    public partial class Form1 : Form
    {
        Dictionary<string, int> miDiccionario = new Dictionary<string, int>();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnAlgo_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            Text.Split("");
            // buscar por aca para separar el texto en espacios
        }
    }
}
