﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Ejercicio_67
{
    public sealed class Temporizador
    {
        private Thread hilo;
        private int intervalo;
        public delegate void encargadoTiempo();

        public event encargadoTiempo EventoTiempo;

        public bool Activo
        {
            get
            {
                if (hilo != null)
                {
                    return hilo.IsAlive;
                }
                else
                {
                    return false;
                }
            }
            set
            {
                    if (this.Activo == false && value == true)
                    {
                        hilo = new Thread(Corriendo);
                        hilo.Start();
                        /*Si el hilo recibe un objet, osea para metodos con parametros, seria por ej
                          hilo = new Thread(new ParameterizedThreadStart(Contar));
                          hilo.Start(25);
                        */
                    }
                    else if (this.Activo == true && value == false)
                    {
                        hilo.Abort();
                    }      
            }
        }
        public int Intervalo
        {
            get
            {
                return intervalo;
            }
            set
            {
                this.intervalo = value;
            }
        }
        private void Corriendo()
        {
            while (true)
            {
                this.EventoTiempo.Invoke();
                Thread.Sleep(intervalo);
            }

        }


    }
}
