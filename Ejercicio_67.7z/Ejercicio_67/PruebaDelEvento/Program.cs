﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio_67;

namespace PruebaDelEvento
{
    class Program
    {  
        static void Main(string[] args)
        {
            Temporizador tempo = new Temporizador();
            tempo.EventoTiempo += metodo; //Aca asocio el evento de la clase instanciada al metodo de la clase local. Puedo Asociar mas 
            tempo.Intervalo = 1000;       //de un metodo al evento y viceversa.
            tempo.Activo = true;
            Console.ReadKey();
        }

        public static void metodo()
        {
            DateTime thisDay = DateTime.Now;
            Console.WriteLine(thisDay.ToString());
        }


    }
}
