﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace Ejercicio_56
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void abrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = @"C:\",
                Title = "Seleccionar archivo...",
                CheckFileExists = true,
                CheckPathExists = true,
                DefaultExt = "txt",
                Filter = "txt files (*.txt)|*.txt",
                FilterIndex = 2,
                RestoreDirectory = true,
                ReadOnlyChecked = true,
                ShowReadOnly = true
            };
            
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {

                string rutaArchivo = openFileDialog1.FileName;
                StringBuilder textoLeido = new StringBuilder();
                using (StreamReader sr = new StreamReader(rutaArchivo))
                {
                    String line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        textoLeido.AppendLine(line);
                    }
                    richTextBox1.Text = textoLeido.ToString();
                }
            }
        }
        //GUARDAR COMO...////////////////////////////////////
        private void guardarComoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog()
            {
                Filter = "Text file (*.txt)|*.txt|C# file (*.cs)|*.cs"
            };
            

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string rutaArchivo2 = saveFileDialog1.FileName;
                using (StreamWriter sw = new StreamWriter(rutaArchivo2))
                {
                    
                    sw.WriteLine(richTextBox1.Text);
                }
            }

        }
    }
}
