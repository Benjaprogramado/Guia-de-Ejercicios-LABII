﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_14
{
    class Program
    {
        static void Main(string[] args)
        {
            string entrada;
            string figura1 = "cuadrado";
            string figura2 = "triangulo";
            string figura3 = "circulo";
            double numeroUno;
            double numeroDos;
            Console.WriteLine("Ingrese figura gemoetrica a calcular: \n");
            entrada = Console.ReadLine();
            
            if(string.Equals(figura1, entrada))
            {
                double area;
                Console.WriteLine("Ingrese medida del lado: \n");
                numeroUno = Convert.ToInt64(Console.ReadLine());
                area = CalculoDeArea.CalcularCuadrado(numeroUno);
                Console.WriteLine("El area del cuadrado es: {0} \n", area);
                Console.ReadKey();

            }
            else if (string.Equals(figura2, entrada))
            {
                double area;
                Console.WriteLine("Ingrese medida de la base: \n");
                numeroUno = Convert.ToInt64(Console.ReadLine());
                Console.WriteLine("Ingrese la altura: \n");
                numeroDos = Convert.ToInt64(Console.ReadLine());
                area = CalculoDeArea.CalcularTriangulo(numeroUno, numeroDos);
                Console.WriteLine("El area del triangulo es: {0} \n", area);
                Console.ReadKey();
            }
            else if (string.Equals(figura3, entrada))
            {
                double area;
                Console.WriteLine("Ingrese medida del radio del circulo: \n");
                numeroUno = Convert.ToInt64(Console.ReadLine());
                area = CalculoDeArea.CalcularCirculo(numeroUno);
                Console.WriteLine("El area del circulo es: {0} \n", area);
                Console.ReadKey();

            }
            else
            {
                Console.WriteLine("Ingrese una opcion correcta");
                Console.ReadKey();
            }
        }
    }
}
