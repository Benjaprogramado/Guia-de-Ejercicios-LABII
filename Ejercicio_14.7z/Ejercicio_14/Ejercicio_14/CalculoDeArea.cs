﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_14
{
    class CalculoDeArea
    {
        public static double CalcularCuadrado (double lado)
        {
            return lado * lado;
        }

        public static double CalcularTriangulo(double piso, double altura)
        {
            return (piso * altura) / 2;
        }
        public static double CalcularCirculo(double radio)
        {
            double aux = Math.Pow(radio, 2);
            return 3.14 * aux;
        }
    }
}
