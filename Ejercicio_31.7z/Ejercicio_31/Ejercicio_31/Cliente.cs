﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_31
{
    public class Cliente
    {
        private string nombre;
        private int numero;

        public string setGetNombre
        {
            set
            {
                this.nombre = value;
            }
            get
            {
                return nombre;
            }
        }
        public int getNumero
        {
            get
            {
                return numero;
            }
            
        }

        public Cliente(int num)
        {
            this.numero = num;
        }
        public Cliente(int num, string nomb) :this(num)
        {
            this.nombre = nomb;
        }

        public static bool operator !=(Cliente c1,Cliente c2)
        {
            if(c1.getNumero != c2.getNumero)
            {
                return true;
            }
            else
            {
                return false;
            }
                
        }
        public static bool operator ==(Cliente c1, Cliente c2)
        {
            if(!(c1 != c2))
            {
                return true;
            }
            else
            {
                return false;
            }
        }





    }
}
