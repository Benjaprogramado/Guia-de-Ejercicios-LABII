﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Ejercicio_31
{
    public class PuestoAtencion
    {
        private int numeroActual;
        private Puesto puesto;
        
        public PuestoAtencion()
        {
            this.numeroActual = default(int);
        }
        public enum Puesto
        {
            Caja1,
            Caja2
        }
        
        public int NumeroActual
        {
            get
            {
                return this.numeroActual;
            }
        }

        public bool AtenderCliente(Cliente cli)
        {
            Random r = new Random(1000);
            int n = r.Next(1000, 5000);//Genero int random
            Thread.Sleep(n);//Hago el tiempo de espera
            return true;
        }



    }

}
