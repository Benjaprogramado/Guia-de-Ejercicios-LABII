﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_16
{
    public class Alumno
    {
        byte nota1;
        byte nota2;
        float notaFinal;
        string apellido;
        int legajo;
        string nombre;

        /// <summary>
        /// Instancia un nuevo alumno.
        /// </summary>
        /// <param name="apellido">Apellido del alumno instanciado.</param>
        /// <param name="legajo">Legajo del alumno instanciado.</param>
        /// <param name="nombre">Nombre del alumno instanciado.</param>
        public Alumno(string apellido, int legajo, string nombre)
        {
            this.apellido = apellido;
            this.nombre = nombre;
            this.legajo = legajo;
        }
        /// <summary>
        /// Carga la nota del alumno.
        /// </summary>
        /// <param name="notaUno">Nota del primer parcial</param>
        /// <param name="notaDos">Nota del segundo parcial</param>
        public void Estudiar(byte notaUno, byte notaDos)
        {
            this.nota1 = notaUno;
            this.nota2 = notaDos;
        }
        /// <summary>
        /// Calcula la nota final del alumno.
        /// </summary>
        public void CalcularFinal()
        {
            Random nota = new Random();
            if (this.nota1 >= 4 && this.nota2 >= 4)
            {
                this.notaFinal = nota.Next(1, 11);
            }
            else
            {
                this.notaFinal = -1;
            }
        }
        /// <summary>
        /// Muestra los datos del alumno referido.
        /// </summary>
        /// <returns>Retorna un string con los datos del objeto alumno.</returns>
        public string Mostrar()
        {
            //return string.Empty; sirve para uso temporal al inicio.
            string legajo = Convert.ToString(this.legajo);
            string Calificacion1 = Convert.ToString(this.nota1);
            string Calificacion2 = Convert.ToString(this.nota2);
            string CalificacionFinal = Convert.ToString(this.notaFinal);
            return "Alumno: "+this.apellido +" "+this.nombre+ "\nLegajo: " + legajo +"\nPrimer nota: "+
                Calificacion1 +"\nSegunda nota: " + Calificacion2 + "\nNota Final: " + CalificacionFinal+"\n\n\n";

            

        }



    }
}
