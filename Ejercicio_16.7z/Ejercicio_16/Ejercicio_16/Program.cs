﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_16
{
    class Program
    {
        static void Main(string[] args)
        {
            //Random r = ner Random();
            //double num = r.Next(1, 11);

            Console.WriteLine("Ingrese Nombre del alumno");
            string nombre = Console.ReadLine();
            Console.WriteLine("Ingrese Apellido del alumno");
            string apellido = Console.ReadLine();
            Console.WriteLine("Ingrese Legajo del alumno");
            int legajo = Convert.ToInt32(Console.ReadLine());

            Alumno alumno1 = new Alumno(apellido, legajo, nombre);

            Console.WriteLine("Ingrese primer nota del alumno");
            byte primerNota = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Ingrese segunda nota del alumno");
            byte segundaNota = Convert.ToByte(Console.ReadLine());

            alumno1.Estudiar(primerNota, segundaNota);
            alumno1.CalcularFinal();

            Console.WriteLine("Ingrese Nombre del alumno");
            string nombre2 = Console.ReadLine();
            Console.WriteLine("Ingrese Apellido del alumno");
            string apellido2 = Console.ReadLine();
            Console.WriteLine("Ingrese Legajo del alumno");
            int legajo2 = Convert.ToInt32(Console.ReadLine());

            Alumno alumno2 = new Alumno(apellido2, legajo2, nombre2);

            Console.WriteLine("Ingrese primer nota del alumno");
            byte primerNota2 = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Ingrese segunda nota del alumno");
            byte segundaNota2 = Convert.ToByte(Console.ReadLine());

            alumno2.Estudiar(primerNota2, segundaNota2);
            alumno2.CalcularFinal();

            Console.WriteLine("Ingrese Nombre del alumno");
            string nombre3 = Console.ReadLine();
            Console.WriteLine("Ingrese Apellido del alumno");
            string apellido3 = Console.ReadLine();
            Console.WriteLine("Ingrese Legajo del alumno");
            int legajo3 = Convert.ToInt32(Console.ReadLine());

            Alumno alumno3 = new Alumno(apellido3, legajo3, nombre3);

            Console.WriteLine("Ingrese primer nota del alumno");
            byte primerNota3 = Convert.ToByte(Console.ReadLine());
            Console.WriteLine("Ingrese segunda nota del alumno");
            byte segundaNota3 = Convert.ToByte(Console.ReadLine());

            alumno3.Estudiar(primerNota3, segundaNota3);
            alumno3.CalcularFinal();



            Console.WriteLine(alumno1.Mostrar());
            Console.WriteLine(alumno2.Mostrar());
            Console.WriteLine(alumno3.Mostrar());
            Console.ReadKey();


        }
    }
}
