﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Figuras;
namespace Ejercicio_de_formas
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Figura> listaFiguras = new List<Figura>();
            listaFiguras.Add(new Circulo(2));
            listaFiguras.Add(new Cuadrado(3));
            listaFiguras.Add(new Rectangulo(4,8));
            listaFiguras[1].GetType();
            listaFiguras[1].Dibujar();
            //completar el poco que falta
        }
    }
}
