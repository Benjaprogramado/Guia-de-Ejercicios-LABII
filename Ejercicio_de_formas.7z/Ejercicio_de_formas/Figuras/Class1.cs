﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figuras
{
    abstract public class Figura
    {
        public virtual string Dibujar()
        {
            return "Dibujando forma...";
        }
        abstract public double CalcularSuperficie(float a, float b);
        abstract public double CalcularPerimetro(float a, float b);
    }



    public class Rectangulo : Figura
    {
        float ladoA;
        float ladoB;

        public Rectangulo(float ladoA, float ladoB)
        {
            this.ladoA = ladoA;
            this.ladoB = ladoB;
        }
        public override string Dibujar()
        {
            return "Dibujando Recatangulo...";
        }
        public override double CalcularSuperficie(float ladoA, float ladoB)
        {
            if(ladoA>0 && ladoB > 0)
            {
                return ladoA * ladoB;
            }
            else
            {
                return 0;
            }
        }
        public override double CalcularPerimetro(float ladoA, float ladoB)
        {
            if (ladoA > 0 && ladoB > 0)
            {
                return (ladoA*2)+(ladoB*2);
            }
            else
            {
                return 0;
            }
        }

    }


    sealed public class Circulo :Figura
    {
        public Circulo(float radio)
        {
            this.radio = radio;
        }
        float radio;

        public override string Dibujar()
        {
            return "Dibujando Circulo...";
        }
        public override double CalcularSuperficie(float radio, float pi)
        {
            if (radio > 0)
            {
                pi = (float)3.14;
                return pi * (radio*radio);
            }
            else
            {
                return 0;
            }
        }
        public override double CalcularPerimetro(float pi, float diametro)
        {
            if (diametro > 0)
            {
                pi = (float)3.14;
                return pi * diametro;
            }
            else
            {
                return 0;
            }
        }



    }


    sealed public class Cuadrado : Rectangulo
    {
        public Cuadrado(float lado) : base(lado, lado)
        {

        }
    }


}
