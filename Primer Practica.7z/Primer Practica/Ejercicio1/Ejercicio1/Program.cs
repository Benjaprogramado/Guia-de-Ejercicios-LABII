﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Primer Clase";
            Console.BackgroundColor = ConsoleColor.DarkBlue;
            string nombre = "Benjamin";
            string apellido = "Schell";
            Console.WriteLine("Hola {0} {1}!!", nombre, apellido);
            Console.ReadKey();
        }
    }
}
