﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Biblioteca_SQL
{
    public static class DAO
    {
        private static SqlConnection connection;
        private static SqlCommand command;
        static DAO()
        {
            string connectionString = @"Data Sources= ; InitialCatalog = BDVet; Integrated Security = true; ";
            connection = new SqlConnection();
            command = new SqlCommand();
            command.Connection = connection;
            command.CommandType = System.Data.CommandType.Text;
        }

        public static void InsertarCliente(string nombre, string apellido, string dni, DateTime fechaNac)
        {
            
            try
            {
                connection.Open();
                string comando = String.Format("INSERT INTO Clientes (Nombre, Apellido, DNI) VALUES ('{0}','{1}','{2}','{3}'", nombre, apellido,dni, fechaNac);
                command.CommandText = comando;

            }
            catch (Exception)
            {

                throw;
            }
            finally
            {

            }             
        }
    }
}
