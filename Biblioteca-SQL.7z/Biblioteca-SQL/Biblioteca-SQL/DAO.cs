﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Biblioteca_SQL
{
    public static class DAO
    {
        private static SqlConnection connection;
        private static SqlCommand command;
        private static string connectionString;

        static DAO()
        {
            connectionString = @"Server= .\SQLEXPRESS; Database = BDvet; Trusted_Connection = true; ";
            connection = new SqlConnection(connectionString);
            command = new SqlCommand();
            command.Connection = connection;
            command.CommandType = System.Data.CommandType.Text;
        }

        public static void InsertarCliente(string nombre, string apellido, string dni, DateTime fechaNac)
        {
            
            try
            {
                connection.Open();
                string comando = String.Format("INSERT INTO Clientes (Nombre, Apellido, DNI, fecha_nacimiento) VALUES ('{0}','{1}','{2}','{3}')", nombre, apellido,dni, fechaNac.ToString("yyyy-MM-dd"));
                command.CommandText = comando;
                command.ExecuteNonQuery();

            }
            finally
            {

            }             
        }
        public static void modificarCliente(int id, string nombre,string apellido, string dni, DateTime? fechaNacimiento)
        {
            using (SqlConnection connection = new SqlConnection(DAO.connectionString))
            {
                string comando = "UPDATE Clientes SET nombre = @nombre," +
                    "apellido = @apellido, dni = @dni, fecha_nacimiento = @fechaNacimiento " +
                    "WHERE id = @id;";
                SqlCommand command = new SqlCommand(comando, connection);
                command.Parameters.AddWithValue("@nombre", nombre);
                command.Parameters.AddWithValue("@apellido", apellido);
                command.Parameters.AddWithValue("@dni", dni);
                command.Parameters.AddWithValue("@fechaNacimiento", fechaNacimiento);
                command.Parameters.AddWithValue("@id", id);
                connection.Open();
                command.ExecuteNonQuery();


            }
        }
        public static List<Clientes> leerCliente()
        {
            using (SqlConnection connection = new SqlConnection(DAO.connectionString));

        }
    }
}
