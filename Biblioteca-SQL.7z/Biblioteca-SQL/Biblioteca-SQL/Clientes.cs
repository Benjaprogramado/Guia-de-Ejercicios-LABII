﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca_SQL
{
    public class Clientes
    {
        private int id;
        private string nombre;
        private string apellido;
        private string dni;
        DateTime fechaNacimiento;

        public Clientes(int id, string nombre, string apellido, string dni, DateTime fechaNacimiento)
        {
            this.id = id;
            this.nombre = nombre;
            this.apellido = apellido;
            this.dni = dni;
            this.fechaNacimiento = fechaNacimiento;
        }


    }
}
