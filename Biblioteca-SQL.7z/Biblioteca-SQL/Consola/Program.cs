﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Biblioteca_SQL;

namespace Consola
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            try
            {
                DAO.InsertarCliente("Pedro", "Picapiedra", "0000001", new DateTime(1850,06,30));
                Console.WriteLine("Registro insertado");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            */

            try
            {
                DAO.modificarCliente(1, "Lalo", "Mir", "12341234", new DateTime(2003, 03, 06));
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.ReadKey();
        }
    }
}
