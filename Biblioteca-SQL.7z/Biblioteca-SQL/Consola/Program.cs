﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Biblioteca_SQL;

namespace Consola
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                DAO.InsertarCliente('Pedro', 'Picapiedra', '0000001', '1850-06-30');
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
