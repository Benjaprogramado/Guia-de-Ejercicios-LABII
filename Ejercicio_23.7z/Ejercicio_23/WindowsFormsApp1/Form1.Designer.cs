﻿namespace WindowsFormsApp1
{
    partial class Coversor
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Coversor));
            this.LabelCotizacion = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.EnterButton1 = new System.Windows.Forms.Button();
            this.EnterButton2 = new System.Windows.Forms.Button();
            this.EnterButton3 = new System.Windows.Forms.Button();
            this.labelEuro1 = new System.Windows.Forms.Label();
            this.labelEuro2 = new System.Windows.Forms.Label();
            this.labelDolar1 = new System.Windows.Forms.Label();
            this.labelDolar2 = new System.Windows.Forms.Label();
            this.labelPeso1 = new System.Windows.Forms.Label();
            this.labelPeso2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LabelCotizacion
            // 
            this.LabelCotizacion.AutoSize = true;
            this.LabelCotizacion.CausesValidation = false;
            this.LabelCotizacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelCotizacion.Location = new System.Drawing.Point(47, 31);
            this.LabelCotizacion.MaximumSize = new System.Drawing.Size(70, 20);
            this.LabelCotizacion.Name = "LabelCotizacion";
            this.LabelCotizacion.Size = new System.Drawing.Size(70, 20);
            this.LabelCotizacion.TabIndex = 0;
            this.LabelCotizacion.Text = "Cotizacion";
            this.LabelCotizacion.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.LabelCotizacion.UseCompatibleTextRendering = true;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.DimGray;
            this.imageList1.Images.SetKeyName(0, "lock-open-solid.png");
            this.imageList1.Images.SetKeyName(1, "lock-solid.png");
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(255, 30);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 1;
            
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(362, 29);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 2;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(469, 28);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 3;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(255, 133);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 4;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(255, 173);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 5;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(255, 210);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 6;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(361, 133);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 20);
            this.textBox7.TabIndex = 7;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(362, 173);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 20);
            this.textBox8.TabIndex = 8;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(362, 210);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 20);
            this.textBox9.TabIndex = 9;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(469, 132);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 20);
            this.textBox10.TabIndex = 10;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(469, 172);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 20);
            this.textBox11.TabIndex = 11;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(469, 209);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 20);
            this.textBox12.TabIndex = 12;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(67, 132);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 20);
            this.textBox13.TabIndex = 13;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(67, 172);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 20);
            this.textBox14.TabIndex = 14;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(67, 209);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(100, 20);
            this.textBox15.TabIndex = 15;
            // 
            // EnterButton1
            // 
            this.EnterButton1.ImageIndex = 0;
            this.EnterButton1.ImageList = this.imageList1;
            this.EnterButton1.Location = new System.Drawing.Point(187, 129);
            this.EnterButton1.Name = "EnterButton1";
            this.EnterButton1.Size = new System.Drawing.Size(50, 24);
            this.EnterButton1.TabIndex = 16;
            this.EnterButton1.Text = "-->";
            this.EnterButton1.UseVisualStyleBackColor = true;
            // 
            // EnterButton2
            // 
            this.EnterButton2.Location = new System.Drawing.Point(187, 169);
            this.EnterButton2.Name = "EnterButton2";
            this.EnterButton2.Size = new System.Drawing.Size(50, 23);
            this.EnterButton2.TabIndex = 17;
            this.EnterButton2.Text = "-->";
            this.EnterButton2.UseVisualStyleBackColor = true;
            // 
            // EnterButton3
            // 
            this.EnterButton3.Location = new System.Drawing.Point(187, 206);
            this.EnterButton3.Name = "EnterButton3";
            this.EnterButton3.Size = new System.Drawing.Size(50, 23);
            this.EnterButton3.TabIndex = 18;
            this.EnterButton3.Text = "-->";
            this.EnterButton3.UseVisualStyleBackColor = true;
            // 
            // labelEuro1
            // 
            this.labelEuro1.AutoSize = true;
            this.labelEuro1.Location = new System.Drawing.Point(7, 135);
            this.labelEuro1.Name = "labelEuro1";
            this.labelEuro1.Size = new System.Drawing.Size(38, 13);
            this.labelEuro1.TabIndex = 19;
            this.labelEuro1.Text = "EURO";
            // 
            // labelEuro2
            // 
            this.labelEuro2.AutoSize = true;
            this.labelEuro2.Location = new System.Drawing.Point(252, 94);
            this.labelEuro2.Name = "labelEuro2";
            this.labelEuro2.Size = new System.Drawing.Size(38, 13);
            this.labelEuro2.TabIndex = 20;
            this.labelEuro2.Text = "EURO";
            // 
            // labelDolar1
            // 
            this.labelDolar1.AutoSize = true;
            this.labelDolar1.Location = new System.Drawing.Point(7, 176);
            this.labelDolar1.Name = "labelDolar1";
            this.labelDolar1.Size = new System.Drawing.Size(44, 13);
            this.labelDolar1.TabIndex = 21;
            this.labelDolar1.Text = "DOLAR";
            // 
            // labelDolar2
            // 
            this.labelDolar2.AutoSize = true;
            this.labelDolar2.Location = new System.Drawing.Point(361, 94);
            this.labelDolar2.Name = "labelDolar2";
            this.labelDolar2.Size = new System.Drawing.Size(44, 13);
            this.labelDolar2.TabIndex = 22;
            this.labelDolar2.Text = "DOLAR";
            // 
            // labelPeso1
            // 
            this.labelPeso1.AutoSize = true;
            this.labelPeso1.Location = new System.Drawing.Point(7, 213);
            this.labelPeso1.Name = "labelPeso1";
            this.labelPeso1.Size = new System.Drawing.Size(36, 13);
            this.labelPeso1.TabIndex = 23;
            this.labelPeso1.Text = "PESO";
            // 
            // labelPeso2
            // 
            this.labelPeso2.AutoSize = true;
            this.labelPeso2.Location = new System.Drawing.Point(469, 94);
            this.labelPeso2.Name = "labelPeso2";
            this.labelPeso2.Size = new System.Drawing.Size(36, 13);
            this.labelPeso2.TabIndex = 24;
            this.labelPeso2.Text = "PESO";
            // 
            // Coversor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(661, 247);
            this.Controls.Add(this.labelPeso2);
            this.Controls.Add(this.labelPeso1);
            this.Controls.Add(this.labelDolar2);
            this.Controls.Add(this.labelDolar1);
            this.Controls.Add(this.labelEuro2);
            this.Controls.Add(this.labelEuro1);
            this.Controls.Add(this.EnterButton3);
            this.Controls.Add(this.EnterButton2);
            this.Controls.Add(this.EnterButton1);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.LabelCotizacion);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Coversor";
            this.Text = "Conversor";
            this.Load += new System.EventHandler(this.Coversor_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LabelCotizacion;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Button EnterButton1;
        private System.Windows.Forms.Button EnterButton2;
        private System.Windows.Forms.Button EnterButton3;
        private System.Windows.Forms.Label labelEuro1;
        private System.Windows.Forms.Label labelEuro2;
        private System.Windows.Forms.Label labelDolar1;
        private System.Windows.Forms.Label labelDolar2;
        private System.Windows.Forms.Label labelPeso1;
        private System.Windows.Forms.Label labelPeso2;
    }
}

