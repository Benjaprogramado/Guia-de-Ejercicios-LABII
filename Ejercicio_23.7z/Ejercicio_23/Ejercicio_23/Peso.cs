﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Peso
    {
        private double cantidad;
        private static double cotizarRespectoDolar;

        #region constructores

        public Peso()
        {
            Peso.cotizarRespectoDolar = (1/38.33);
        }
        public Peso(double cantidad) : this()
        {
            this.cantidad = cantidad;
        }
        public Peso(double cantidad, double cotizacion) : this(cantidad)
        {
            cotizarRespectoDolar = cotizacion;
        }

        #endregion

        #region metodos

        public static double GetCotizacion()
        {
            return Peso.cotizarRespectoDolar;
        }
        public double GetCantidad()
        {
            return this.cantidad; 
        }

        #endregion

        #region conversiones

        public static explicit operator Dolar(Peso p)
        {
            double cantidad = p.GetCantidad() / Peso.cotizarRespectoDolar;
            Dolar dolar = new Dolar(cantidad);
            return dolar;
        }
        public static explicit operator Euro(Peso p)
        {

            double cantidad = p.GetCantidad();
            Euro euro = new Euro(cantidad);   
            return euro;
        }
        public static implicit operator Peso(double d)
        {
            Peso aux = new Peso(d);
            return aux;
        }

        #endregion

        #region Operaciones
        public static Peso operator +(Peso p, Euro e)
        {
            Peso aux = new Peso(p.cantidad + ((Peso)e).cantidad);
            return aux;
        }

        public static Peso operator +(Peso p, Dolar d)
        {
            Peso aux = new Peso(p.cantidad + ((Peso)d).cantidad);
            return aux;
        }

        public static Peso operator -(Peso p, Euro e)
        {
            Peso aux = new Peso(p.cantidad - ((Peso)e).cantidad);
            return aux;
        }

        public static Peso operator -(Peso p, Dolar d)
        {
            Peso aux = new Peso(p.cantidad - ((Peso)d).cantidad);
            return aux;
        }
        #endregion

        #region Comparaciones
        public static bool operator ==(Peso p1, Peso p2)
        {
            return p1.cantidad == p2.cantidad;
        }

        public static bool operator !=(Peso p1, Peso p2)
        {
            return !(p1 == p2);
        }

        public static bool operator ==(Peso p, Euro e)
        {
            return p == (Peso)e;
        }

        public static bool operator !=(Peso p, Euro e)
        {
            return !(p == e);
        }

        public static bool operator ==(Peso p, Dolar d)
        {
            return p == (Peso)d;
        }

        public static bool operator !=(Peso p, Dolar d)
        {
            return !(p == d);
        }
        #endregion


    }


}
