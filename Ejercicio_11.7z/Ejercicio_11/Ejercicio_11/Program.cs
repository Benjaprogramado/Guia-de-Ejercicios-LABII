﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_11
{
    class Program
    {
        static void Main(string[] args)
        {
            int min = 100;
            int max = -100;
            int promedio = 0;
            int acumulador = 0;
            bool flagError = false;
            int contador = default(int);

            do
            {
                Console.WriteLine("Imgrese un numero");
                string entrada = Console.ReadLine();
                int numero = Convert.ToInt32(entrada);

                if((Validacion.Validar(numero, -100, 100)) == false)
                {
                    Console.WriteLine("Error, numero incorrecto");
                    Console.ReadKey();
                    flagError = true;
                    break;
                }

                if (numero < min)
                {
                    min = numero;
                }
                if(numero > max)
                {
                    max = numero;
                }
                contador++;
                acumulador += numero;


                promedio = acumulador / contador;
            } while (contador < 10);

            if(flagError == false)
            {
                Console.WriteLine("El maximo es {0}\nEl minimo es {1}\nEl Promedio es {2}", max, min, promedio);
                Console.ReadKey();
            }




        }
    }
}
