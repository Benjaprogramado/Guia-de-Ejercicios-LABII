﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            bool flag = true;
            float promedio=0;
            int maximo=0;
            int minimo=0;
            int acumulador = 0;

            for (int i=0; i<5; i++)
                {
                Console.WriteLine("Ingrese un Numero:  "); 
                numero = Convert.ToInt32(Console.ReadLine());
                acumulador += numero;
                if (flag)
                {
                    maximo = numero;
                    minimo = numero;
                    flag = false;
                }
                else
                {
                    if(numero>maximo)
                    {
                        maximo = numero;
                    }
                    if(numero<minimo)
                    {
                        minimo = numero;
                    }
                }




                }
            promedio = acumulador / 5;
            Console.WriteLine("El maximo es {0}, el minimo es {1}, y el promedio es {2}", maximo, minimo, promedio);
            Console.ReadKey();

        }
    }
}
