﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_42
{
    class ClaseTres
    {
        public ClaseTres()
        {
            try
            {
                new ClaseDos();
            }
            catch(DivideByZeroException e)
            {
                throw new UnaExcepcion(fallo, e)
            }
            
            

        }
    }
}
