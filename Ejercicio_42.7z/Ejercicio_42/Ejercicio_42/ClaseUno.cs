﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_42
{
    class ClaseUno
    {

        public static void MetodoEstatico()
        {

         throw new DivideByZeroException("Estoy en el metodo estatico");
        }


    }
}
