using System;
using System.Collections.Generic;
using System.Text;




namespace Entidades
{
    
    public class Agua : Botella
    {
        private const int MEDIDA = 400;
        private Tipo tipo;

        public Agua(int capacidadML, string marca, int contenidoML) : base(marca, capacidadML, contenidoML)
        {

        }
        
        public int ServirMedida(int medida)
        {
            if (medida > this.Contenido)
            {
                this.Contenido = 0;
            }
            else
            {
                this.Contenido = this.Contenido- medida;
                
            }
            return this.Contenido;
        }
        public override int ServirMedida()
        {
            
            this.ServirMedida(MEDIDA);
            return this.Contenido;
        }

        public string GenerarInforme()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            sb.AppendFormat("Medida: {0}",Convert.ToString(MEDIDA));
            return sb.ToString();
        }






    }
}
