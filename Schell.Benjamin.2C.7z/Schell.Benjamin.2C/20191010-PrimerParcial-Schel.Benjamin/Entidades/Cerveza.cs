using System;
using System.Collections.Generic;
using System.Text;


namespace Entidades
{
    public class Cerveza : Botella
    {
        private const int MEDIDA = 330;
        Tipo tipo;



        public Cerveza(int capacidadML, string marca,Tipo tipo, int contenidoML) : base(marca, capacidadML, contenidoML)
        {
            this.tipo = tipo;
        }
        public Cerveza(int capacidadML, string marca, int contenidoML) : base(marca,capacidadML, contenidoML)
        {
            
        }

    public override int ServirMedida()
        {
            int otraMEDIDA = (80 * MEDIDA) / 100;
            if (otraMEDIDA > this.Contenido)
            {
                this.Contenido = 0;
            }
            else
            {
                this.Contenido = this.Contenido - otraMEDIDA;

            }
            return this.Contenido;
        }

        public string GenerarInforme()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.ToString());
            sb.AppendFormat("Medida: {0}", Convert.ToString(MEDIDA));
            sb.AppendFormat("Tipo: {0}", tipo);
            return sb.ToString();
        }


    }
}
