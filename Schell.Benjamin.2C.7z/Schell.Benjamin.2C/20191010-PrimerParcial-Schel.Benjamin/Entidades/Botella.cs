﻿using System;
using System.Text;


namespace Entidades
{
    public abstract class Botella
    {
        public enum Tipo
        {
            Plastico, Vidrio
        }

        private int capacidadML;
        private int contenidoML;
        private string marca;

        #region propiedades

        public int CapacidadLitros
        {
            get
            {
                return this.capacidadML / 100;
            }
        }
        public int Contenido
        {
            get
            {
                return this.contenidoML;
            }
            set
            {
                this.contenidoML=value;
            }
        }
        public float PorcentajeContenido
        {
            get
            {
                return (this.contenidoML*100)/this.capacidadML;
            }
        }
        #endregion
        #region constructores
        public Botella(string marca, int capacidadML, int contenidoML)
        {
            this.marca = marca;
            this.capacidadML = capacidadML;
            if (this.capacidadML < contenidoML)
            {
                this.contenidoML = capacidadML;
            }
            else
            {
                this.contenidoML = contenidoML; 
            }
        }
        #endregion
        #region metodos
        public abstract int ServirMedida();
        private string GenerarInforme()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Datos de la Botella");
            sb.AppendFormat("Marca: {0}", this.marca);
            sb.AppendFormat("Capacidad: {0}",Convert.ToString(this.capacidadML));
            sb.AppendFormat("Contenido {0}",Convert.ToString(this.contenidoML));

            return sb.ToString();
        }
        public override string ToString()
        {
            return this.GenerarInforme();
        }

        #endregion

    }
}
