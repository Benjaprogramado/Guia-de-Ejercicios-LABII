﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public class Cantina
    {
        private List<Botella> botellas;
        private int espaciosTotales;
        private Cantina singleton= null;


        private Cantina(int espacios)
        {
            this.espaciosTotales = espacios;
            this.botellas = new List<Botella>();
        }

        public List<Botella> Botellas
        {
            get
            {
                return this.botellas;
            }
        }

        public static bool operator +(Cantina c, Botella b)
        {
            if (c.espaciosTotales > 0)
            {
                c.botellas.Add(b);
                c.espaciosTotales--;
                return true;
            }
            else
            {
                return false;
            }
        }

        public Cantina GetCantina(int espacios)
        {
            if (singleton == null)
            {
                return singleton=new Cantina(espacios);
            }
            else
            {
                singleton.espaciosTotales--;
                return singleton;
            }
        }
    }
}
