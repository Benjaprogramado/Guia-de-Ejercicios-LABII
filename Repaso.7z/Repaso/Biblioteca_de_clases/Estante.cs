﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca_de_clases
{
    public class Estante
    {
        private Producto[] productos;
        private int ubicacionEstante;



        private Estante(int cantidad)
        {
            this.productos = new Producto[cantidad];

        }
        public Estante(int cantidad, int ubicacion) : this(cantidad)
        {
            this.ubicacionEstante = ubicacion;
        }


        public Producto[] GetProductos(Estante nombreEstante)
        {

            return nombreEstante.productos;
            
        }

        public string MostrarEstante(Estante nombreEstante)
        {
            foreach()

            return "ss";
        }


    }
}
