﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca_de_clases
{
    public class Producto
    {
        private string codigoDeBarra;
        private string marca;
        private float precio;


        public Producto(string codigoDeBarra, string marca, float precio)
        {
            this.codigoDeBarra = codigoDeBarra;
            this.marca = marca;
            this.precio = precio;
        }

        public string GetMarca()
        {
            if (this.marca != null)
            {
                return this.marca;
            }
            else
            {
                return string.Empty;
            }
        }

        public float GetPrecio()
        {
            if (this.precio != 0)
            {
                return this.precio;
            }
            else
            {
                return -1;
            }
        }

        public string MostrarProducto()
        {
            string precio = Convert.ToString(this.precio);
            return "Codigo de Barra: " + this.codigoDeBarra + " " + "\nMarca: "
                    + this.marca + "\nPrrecio: " +
                    this.precio + "\n\n\n";
        }

        public static explicit operator String(Producto x)
        {
            return x.marca;
        }

        public static bool operator ==(Producto a, string b)
        {
            if(a.marca == b)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator !=(Producto a, string b)
        {
            if (!(a.marca == b))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public static bool operator ==(Producto a, Producto b)
        {
            if (a.marca == b.marca && a.codigoDeBarra == b.codigoDeBarra)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator !=(Producto a, Producto b)
        {
            if (!(a == b))
            {
                return true;
            }
            else
            {
                return false;
            }
        }





    }
}
