﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class HilosForm : Form
    {
        private Thread hilo;
        private delegate void Callback(object o);

        public HilosForm()
        {
            InitializeComponent();
        }

        private void buttonEscribir_Click(object sender, EventArgs e)
        {
            this.richTextBoxTexto.Text += this.textBoxEscribir.Text + "\n";
            this.textBoxEscribir.Clear();
        }

        private void HilosForm_Load(object sender, EventArgs e)
        {
            hilo = new Thread(new ParameterizedThreadStart(Contar));
            hilo.Start(25);
        }

        private void Contar(object intervaloSeg)
        {
            while(true)
            {
                
                this.ActualizarLabel(intervaloSeg);
                Thread.Sleep(1000);
            }
        }

        private void ActualizarLabel(object parametros)
        {
            if (this.labelContador.InvokeRequired)
            {
                
                Callback callback = new Callback(this.ActualizarLabel);
                this.labelContador.Invoke(callback, new object[] {parametros});
            }
            else
            {
                this.labelContador.Text = (Convert.ToInt32(this.labelContador.Text)+(int)parametros).ToString();
            }
        }

        private void HilosForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(this.hilo != null || this.hilo.IsAlive)
            {
                hilo.Abort();
            }
        }

        //private void ContarASaltos(object cantidadASaltar)
        //{
        //    while(true)
        //    {
        //        this.ActualizarLabel(cantidadASaltar);
        //        Thread.Sleep(1000);
        //    }
        //}

        //private void ActualizarLabel(object cantidadASaltar)
        //{
        //    if (this.labelContador.InvokeRequired)
        //    {
        //        object[] parametros = new object[] { cantidadASaltar };
        //        this.labelContador.Invoke(new Callback(this.ActualizarLabel), parametros);
        //    }
        //    else
        //    {
        //        this.labelContador.Text = (Convert.ToInt32(this.labelContador.Text) + (int) cantidadASaltar).ToString();
        //    }
        //}
    }
}
