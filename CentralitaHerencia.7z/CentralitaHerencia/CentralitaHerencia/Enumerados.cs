﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public enum EnumeradoPrueba { Constante0, Constante1, Constante2, Constante15 = 15}
}
