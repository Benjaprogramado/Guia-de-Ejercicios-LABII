﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Llamada
    {
        protected float duracion;
        protected string nroDestino;
        protected string nroOrigen;

        public Llamada(float duracion, string nroOrigen, string nroDestino)
        {
            this.duracion = duracion;
            this.nroDestino = nroDestino;
            this.nroOrigen = nroOrigen;
        }

        public enum TipoDeLlamada
        {
            Local,
            Provincial,
            Todas
        }


        public float getDuracion
        {
            get
            {
                return duracion;
            }
        }
        public string getNroDestino
        {
            get
            {
                return nroDestino;
            }
        }
        public string getNroOrigen
        {
            get
            {
                return nroOrigen;
            }
        }
        int compare(int a, int b)
        {
            if (a == b)
            {
                return 0;
            }
            else if (a < b)
            {
                return 1;
            }
            else
            {
                return -1;
            }

        }
        public int OrdenarPorDuracion(Llamada llamada1, Llamada llamada2)
        {
            if (llamada1.getDuracion < llamada2.getDuracion)
            {
                return -1;
            }
            else if(llamada1.getDuracion == llamada2.getDuracion)
            {
                return 0;
            }
            else
            {
                return 1;
            }

        }
        public string mostrar()
        {
            StringBuilder sb = new StringBuilder("Detalle de la llamada:\n");

            sb.AppendLine(this.getNroOrigen);
            sb.AppendLine(this.getNroDestino);
            string duracion = Convert.ToString(this.getDuracion);
            sb.AppendLine(duracion);

            string datos = sb.ToString();
            return datos;
        }

        



    }
}
