﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Provincial : Llamada
    {
        protected Franja franjaHoraria;

        public Provincial(Franja miFranja, Llamada llamada) : base(llamada.getDuracion, llamada.getNroOrigen, llamada.getNroDestino)
        {
            this.franjaHoraria = miFranja;
        }
        public Provincial(string origen, Franja mifranja, float duracion, string destino) : base(duracion, origen, destino)
        {

            this.franjaHoraria = mifranja;
        }

        public enum Franja
        {
            Franja_1,
            Franja_2,
            Franja_3
        }

        public float CostoLlamada
        {
            get
            {
                return this.CalcularCosto();
            }
        }


        public string Mostrar()
        {
            string datosHeredados = this.Mostrar();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(datosHeredados);
            sb.AppendLine(Convert.ToString(this.CostoLlamada));
            sb.AppendLine(Convert.ToString(this.franjaHoraria));
            return sb.ToString();
        }

        private float CalcularCosto()
        {
            if ((this.franjaHoraria == Franja.Franja_1))
            {
                float duracion = this.getDuracion;
                return duracion * (float)0.99;
            }
            else if ((int)this.franjaHoraria==1)
            {
                float duracion = this.getDuracion;
                return duracion * (float)1.25;
            }
            else if((int)this.franjaHoraria == 2)
            {
                float duracion = this.getDuracion;
                return duracion * (float)0.66;
            }
            else
            {
                return 0;
            }

        }



    }
}
