﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Local : Llamada
    {
        protected float costo;


        public Local(Llamada llamada, float costo) : base(llamada.getDuracion, llamada.getNroOrigen, llamada.getNroDestino)
        {
            this.costo = costo;
        }
        public Local(float duracion, string origen, string destino, float costo) :base(duracion, origen,destino)
        {

            this.costo=costo;
        }


        public float getCostoLlamada
        {
            get
            {
                return costo;
            }
        }

        private float CalcularCosto()
        {
            return this.getCostoLlamada * this.getDuracion;
        }

        public string Mostrar()
        {
            string datosHeredados = this.Mostrar();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(datosHeredados);
            sb.AppendLine(Convert.ToString(this.getCostoLlamada));        
            return sb.ToString();
        }







    }


       
}
