﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Local : Llamada
    {
        protected float costo;


        public Local(Llamada llamada, float costo) : base(llamada.getDuracion, llamada.getNroOrigen, llamada.getNroOrigen)
        {
            this.costo = costo;
        }
        /*public Local(float duracion, string origen, string destino, float costo)
        {

        }*/


        public float getCostoLlamada
        {
            get
            {
                return costo;
            }
        }

        private float CalcularCosto()
        {
            return this.getCostoLlamada * this.getDuracion;
        }








    }


       
}
