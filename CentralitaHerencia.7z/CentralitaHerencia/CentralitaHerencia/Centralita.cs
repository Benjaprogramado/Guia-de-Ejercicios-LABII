﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Centralita
    {
        protected List<Llamada> listaDeLlamadas;
        protected string razonSocial;



        public Centralita()
        {
            this.listaDeLlamadas = new List<Llamada>();
        }
        public Centralita(string nombreEmpresa)
        {
            this.razonSocial = nombreEmpresa;
        }



        private float CalcularGanacia(Llamada.TipoDeLlamada tipo)
        {

        }



    }
}
