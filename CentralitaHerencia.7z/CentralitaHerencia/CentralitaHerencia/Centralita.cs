﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Centralita
    {
        private List<Llamada> listaDeLlamadas;
        protected string razonSocial;



        public Centralita()
        {
            this.listaDeLlamadas = new List<Llamada>();
        }
        public Centralita(string nombreEmpresa)
        {
            this.razonSocial = nombreEmpresa;
        }



        private float CalcularGanancia(Llamada.TipoDeLlamada tipo)
        {
            foreach(Llamada ll in listaDeLlamadas)
            {           
                if(tipo==Llamada.TipoDeLlamada.Local)
                {
                    float gananciaLocal = 0;
                    Local llamada = (Local)ll;
                    float aux = llamada.getCostoLlamada;
                    gananciaLocal += aux;
                    return gananciaLocal;
                }
                else if (tipo==Llamada.TipoDeLlamada.Provincial)
                {
                    float gananciaProvincial = 0;
                    Provincial llamada = (Provincial)ll;
                    float aux = llamada.CostoLlamada;
                    gananciaProvincial += aux;
                    return gananciaProvincial;
                }
                else if (tipo == Llamada.TipoDeLlamada.Todas)
                {//corregir esto para que diferencia una de otra, otro if probablemente
                    float gananciaProvincial = 0;
                    Provincial llamada = (Provincial)ll;
                    float aux = llamada.CostoLlamada;
                    gananciaProvincial += aux;

                    float gananciaLocal = 0;
                    Local llamada2 = (Local)ll;
                    float aux2 = llamada2.getCostoLlamada;
                    gananciaLocal += aux;

                    return gananciaProvincial+gananciaLocal;
                }
                else
                {
                    return 0;
                }

            }
        }








    }
}
