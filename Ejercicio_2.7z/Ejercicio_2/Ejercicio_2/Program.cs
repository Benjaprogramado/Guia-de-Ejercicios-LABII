﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_2
{
    class Program
    {
        static void Main(string[] args)
        {
            double cuadrado;
            double cubo;
            double numero = default(double);// Es igual a inicializar el double en cero.
            string entrada;
            do
            {
                Console.WriteLine("Ingrese un numero: ");
                entrada = Console.ReadLine();
                numero = Convert.ToInt64(entrada);
                /*Tambien puedo usar "Int32.TryToParse("entrada", out "variable de salida")", 
                esto devuelve un booleano y serviria para validar el ingreso numerico.*/
                if (numero < 0) 
                 {
                    Console.WriteLine("ERROR, reingresar numero");
                    Console.ReadKey();
                    Console.Clear();
                 }
            } while (numero < 0);

            cuadrado = Math.Pow(numero, 2);
            cubo = Math.Pow(numero, 3);


            Console.WriteLine("El cuadrado del numero es: {0}\nEl cubo del numero es {1}", cuadrado, cubo);
            Console.ReadKey();
        }
    }
}
