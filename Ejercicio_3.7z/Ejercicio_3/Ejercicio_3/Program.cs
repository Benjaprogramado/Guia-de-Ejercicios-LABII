﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_3
{
    class Program
    {
        static void Main(string[] args)
        {
            long numero;
            string entrada;
            


            Console.WriteLine("Ingrese un numero: ");
            entrada = Console.ReadLine();
            numero = Convert.ToInt64(entrada);

            for (int i=1; i<=numero; i++)
            {
                int aux = 1;
                int contador = default(int);
                do
                 {
                    if (i % aux == 0)
                    {
                        contador++;
                    }
                    aux++;

                 } while (aux <= i);

                if (contador == 2)
                {
                    Console.WriteLine("Es primo el: {0}\n", i);
                }
            }

            Console.ReadKey();

        }
    }
}
