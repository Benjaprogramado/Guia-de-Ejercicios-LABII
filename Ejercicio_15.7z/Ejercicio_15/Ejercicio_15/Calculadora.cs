﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_15
{
    class Calculadora
    {
        private static bool validar(int numero)
        {
            if (numero == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public static int Calcular(int primerNum, int segundoNum, string operacion)
        {
       
            string sumar = "+";
            string restar = "-";
            string multiplicar = "*";
            string dividir = "/";

            if (string.Equals(operacion, sumar))
            {
                return primerNum + segundoNum;
            }
            else if (string.Equals(operacion, restar))
            {
                return primerNum - segundoNum;
            }
            else if (string.Equals(operacion, multiplicar))
            {
                return primerNum * segundoNum;
            }
            else if (string.Equals(operacion, dividir))
            {
                if(validar(segundoNum)== false)
                {
                    return primerNum / segundoNum;
                }
                else
                {
                    Console.WriteLine("No se puede dividir por cero!!!");
                    Console.ReadKey();
                    return -1;
                }

                
            }
            else
            {
                return -1;
            }

            



        }
    }
}
