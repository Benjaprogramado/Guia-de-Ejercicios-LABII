﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_15
{
    class Program
    {
        static void Main(string[] args)
        {
            string respuesta = "s";
            do
            {
                Console.WriteLine("Ingrese el primer numero: ");
                int primerNum = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Ingrese el segundo numero: ");
                int segundoNum = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Ingrese el operacion a realizar: ");
                string operacion = (Console.ReadLine());

                int resultado = Calculadora.Calcular(primerNum, segundoNum, operacion);
                Console.WriteLine("El resultado es: {0}", resultado);

                Console.WriteLine("Desea continuar");      
                respuesta = Convert.ToString(Console.ReadLine());

            } while (respuesta == "s");
        }
    }
}
