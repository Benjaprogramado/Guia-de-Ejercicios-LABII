﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_4
{
    class Program
    {
        static void Main(string[] args)
        {

            long numero;
            string entrada;

          
            


            Console.WriteLine("Ingrese un numero: ");
            entrada = Console.ReadLine();
            numero = Convert.ToInt64(entrada);

            for (int i=1; i<numero; i++)
            {
                int sumador = default(int);

                for (int j=1; j < numero; j++)
                {
                    if(i % j == 0)
                    {
                        sumador += j;
                        if (sumador == i)
                        {
                            Console.WriteLine("Es perfecto: {0}", j);
                        }
                    }

                }

            }

            Console.ReadKey();


        }
    }
}
