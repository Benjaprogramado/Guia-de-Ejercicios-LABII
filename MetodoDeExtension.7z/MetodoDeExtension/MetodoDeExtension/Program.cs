﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MetodoDeExtension;

namespace MetodoDeExtension
{
    class Program
    {
        static void Main(string[] args)
        {
            string miHolaMundo = "Hola mundo soy Yo";
            int cantidad = miHolaMundo.ContarPalabras();
            Console.WriteLine("Mi saludo es: {0} , y tiene {1} palabras", miHolaMundo, cantidad);
            Console.ReadKey();
        }
    }
}
