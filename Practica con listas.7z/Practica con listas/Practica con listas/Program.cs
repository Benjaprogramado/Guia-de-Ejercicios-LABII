﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practica_con_listas
{
    class Program
    {
        static void Main(string[] args)
        {
            //METODO PARA UTILIZAR EN EL SORT DE LA LISTA

            int compare(int a, int b)
            {
                if (a == b)
                {
                    return 0;
                }
                else if (a < b)
                {
                    return 1;
                }
                else
                {
                    return -1;
                }              

            }

            //GENERACION Y CARGA DE LA LISTA

            List<int> numeros;
            numeros = new List<int>();
            // Agrego
            numeros.Add(11);
            numeros.Add(41);
            numeros.Add(1);
            numeros.Add(9);
            numeros.Add(13);

            //MUESTRO LA LISTA

            foreach (int numero in numeros)
            {
                Console.WriteLine("{0}\n", numero);
            }

            Console.ReadKey();

            //ORDENO LA LISTA Y MUESTRO NUEVAMENTE

            /*numeros.Sort(compare);

            foreach (int numero in numeros)
            {
                Console.WriteLine("\n{0}\n", numero);
            }

            Console.ReadKey();
            */
            /*
            //GENERACION Y CARGA DEL QUEUE (COLA)
            Queue<int> pila = new Queue<int>();
            foreach (int numero in numeros)
            {
                pila.Enqueue(numero);        
            }
            foreach (int numero in pila)
            {
                Console.WriteLine("\n{0}\n", numero);
            }

            Console.ReadKey();
            */

            //GENERACION Y CARGA DEL STACK (PILA)
            /*
            Stack<int> stack = new Stack<int>();
            foreach (int numero in numeros)
            {
                stack.Push(numero);
            }
            foreach (int numero in stack)
            {
                Console.WriteLine("\n{0}\n", numero);
            }

            Console.ReadKey();
            */

            //GENERO DICCIONARIO, CARGO DATOS Y MUESTRO CONTENIDO
            Dictionary<long, string> personas = new Dictionary<long , string>();
            personas.Add(33254252, "juan");
            personas.Add(33987654, "pedro");
            personas.Add(32123654, "susana");
            personas.Add(30121666, "enrrique");
            foreach(KeyValuePair<long ,string> datos in personas)
            {
                Console.WriteLine("DNI y Nombre: {0}", datos);
            }
            Console.ReadKey();
        }
    }
}
